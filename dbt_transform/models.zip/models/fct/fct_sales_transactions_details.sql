SELECT *
FROM {{ ref('int_sales_transactions_details') }}
